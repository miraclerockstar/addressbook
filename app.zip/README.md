addressbook
===========
    Firstname
    Lastname
    Street and number
    Zip
    City
    Country
    Phonenumber
    Birthday
    Email address
    Picture (optional)


Please use the following techniques:

    Symfony 3.4
    Doctrine with SQLite
    Twig
    PHP 7.0
